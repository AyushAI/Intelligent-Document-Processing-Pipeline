from google import genai

client = genai.Client(api_key="AIzaSyC5U9oN3zUIGXL9t33get1_BGfjk3DqCw0")

MODEL_NAME = "gemini-2.5-flash"
